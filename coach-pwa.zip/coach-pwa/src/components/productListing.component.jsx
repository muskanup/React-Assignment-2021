import React from "react";
import Product from "./product.component";
import '../styles/style.css';
  
  class ProductListing extends React.Component {
    constructor(props) {
        super(props)
        this.state = { 
            isLoading: true,
            products: [],
            filteredProducts: [],
            clicked: false
        }
        this.sortByPriceAsc = this.sortByPriceAsc.bind(this);
        this.sortByPriceDesc = this.sortByPriceDesc.bind(this);
    }

    fetchPosts() {
      fetch(`http://makeup-api.herokuapp.com/api/v1/products.json?brand=maybelline`)
        .then(response => response.json())
        .then(
          data =>
            this.setState({
              products: data,
              filteredProducts: data,
              isLoading: false,
            })
        )
        .catch(error => this.setState({ error, isLoading: false }));
    }

    componentDidMount() {
      this.fetchPosts();
    }

    sortByPriceAsc() {
        let newProductsList = this.state.products.sort((a, b) => (a.price - b.price));
        this.setState({ filteredProducts: newProductsList});
    }
    
    sortByPriceDesc() {
        let newProductsList = this.state.products.sort((a, b) => (b.price - a.price));
        this.setState({ filteredProducts: newProductsList});
    }

    setFilterType(filterOption) {
        console.log("Filter Option", filterOption);
        let newProductsList = this.state.products.filter(option => option.product_type === filterOption);
        this.setState({ filteredProducts: newProductsList});
    }
  
    render() {
      const { isLoading } = this.state;
      var allProducts = this.state.filteredProducts.map((product) =>(
        <Product productdetails={product} />
      ));
      return (
        <div className="container">
            <h1 className="mt-5">New Arrivals</h1>
            <div className="row mt-5">
                <div className="col-lg-3 bg-light">
                    <div>
                        <h5 className="mt-3">Sorting Options</h5>
                        <div class="btn-group-vertical" role="group">
                            <button type="button" className="btn btn-secondary product_sort_asc" onClick={this.sortByPriceAsc}>Price Low to High</button>
                            <button type="button" className="btn btn-secondary product_sort_desc" onClick={this.sortByPriceDesc}>Price High to Low</button>
                        </div>
                    </div>
                    <div>
                        <h5 className="mt-3">Filter Options</h5>
                        <select className="w-100 bg-light" onChange={(e) => this.setFilterType(e.target.value)}> 
                            <option value="select">Select Type</option>
                            <option value="bronzer">Bronzer</option>
                            <option value="blush">Blush</option>
                            <option value="lip_liner">Lip Liner</option>
                            <option value="foundation">Foundation</option>
                            <option value="eyeshadow">Eye Shadow</option>
                            <option value="eyeliner">Eye Liner</option>
                            <option value="nail_polish">Nail Polish</option>
                            <option value="lipstick">Lipstick</option>
                            <option value="mascara">Mascara</option>
                        </select>
                    </div>
                </div>
                <div className="col-md-9">
                    {!isLoading ? <div className="row">{allProducts}</div> : <h3>Loading...</h3>}
                </div>
            </div>
        </div>
      );
    }
  }

  export default ProductListing;

