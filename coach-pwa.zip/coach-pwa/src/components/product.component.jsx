import React from "react";
import { Link } from 'react-router-dom';

class Product extends React.Component {
    render() {
        return (
            <div className="col-md-3 mb-4" key={this.props.productdetails.id}>
                <div className="card h-100 mb-20">
                    <img 
                        height="250px" 
                        width="200px"
                        src={this.props.productdetails.image_link}
                        alt={this.props.productdetails.name}
                        className="card-img-top"
                    />
                    <div className="card-body border-top">
                        <Link to={`/new-arrivals/${this.props.productdetails.id}`} className="d-block text-truncate">{this.props.productdetails.name}</Link>
                        <h6 className="mt-2">${this.props.productdetails.price}</h6>
                    </div>
                </div>
            </div>
        );
    }
}

export default Product;