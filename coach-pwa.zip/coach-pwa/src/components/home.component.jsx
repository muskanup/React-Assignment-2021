import React from 'react';
import {Link} from 'react-router-dom';
import "../styles/style.css";

class Home extends React.Component {
    render(){
        return(       
            <div className="align-center bg-light">
                <nav className="bg-dark">
                    <Link to="/" className="nav-item">HOME</Link> |{" "}
                    <Link to="/new-arrivals" className="nav-item">NEW ARRIVALS</Link>
                </nav>
                <img class="w-100" src="https://cms.coachoutlet.com/i/coachoutlet/20211208-m4-img-desktop?$poi$&w=1400&fmt=jpg&$qlt_med$" alt="IMG1"/>
            </div>
        );
    }
}

export default Home;
