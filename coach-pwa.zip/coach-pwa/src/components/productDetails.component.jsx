import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams } from 'react-router-dom';
import '../styles/style.css';


const ProductDetails = () => {
  const [data, setData] = useState([]);
  const {id} = useParams();
  let newArray = [];
useEffect(() => {
    fetchProduct();
  }, []);
const fetchProduct = () => {
    axios
      .get(
        `http://makeup-api.herokuapp.com/api/v1/products/${id}.json`
      )
      .then((res) => {
        newArray.push(res.data);
        setData(newArray);
      })
      .catch((err) => console.log(err));
  };
return (
    <div>
      {data.map((item) => {
        return (
            <div className="container">
                <div className="row mt-5">
                    <div className="col-md-6">
                        <img className='prod-image' src={item.image_link} alt='' />
                    </div>
                    <div className="col-md-6">
                        <h2 className="mt-5">{item.name}</h2>
                        <p>{item.description}</p>
                        <p>
                            <strong>Price:</strong> ${item.price}
                        </p>
                        <p>
                            <strong>Rating:</strong> {item.rating}
                        </p>
                    </div>
                </div>
            </div>
        );
      })}

    </div>
  );
};
export default ProductDetails;