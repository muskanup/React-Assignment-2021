import Home from './components/home.component';
import ProductListing from './components/productListing.component';
import ProductDetails from './components/productDetails.component';
import {Routes, Route} from 'react-router-dom';

function App() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/new-arrivals" element={<ProductListing />} />
      <Route path='/new-arrivals/:id' element={<ProductDetails />} />
    </Routes>
  );
}

export default App;
